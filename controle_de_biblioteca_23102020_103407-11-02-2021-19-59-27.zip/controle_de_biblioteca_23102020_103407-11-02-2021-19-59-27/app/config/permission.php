<?php 
return[
    'host' => "localhost",
    'name' => "biblioteca_permission",
    'user' => "root",
    'pass' => "670477",
    'type' => "mysql",
    'prep' => "1",
    'slog' => "SystemSqlLogService"
];